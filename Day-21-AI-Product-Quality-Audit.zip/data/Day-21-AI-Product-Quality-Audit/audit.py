
import csv
import json
import statistics
import time
from pathlib import Path

# Import the Day 20 pipeline from the parent folder.
# Run this script from inside Day-21-AI-Product-Quality-Audit.
import sys
DAY20 = Path(__file__).resolve().parent.parent / "Day-20-AI-Knowledge-Assistant"
sys.path.insert(0, str(DAY20))

from rag_pipeline import (
    client,
    MODEL_NAME,
    retrieve_top_k,
    format_context,
    RAG_SYSTEM_PROMPT,
)

OUT = Path(__file__).resolve().parent / "results"
OUT.mkdir(exist_ok=True)

# 10 grounded accuracy/reliability/transparency queries.
# Expected answers are deliberately simple and directly supported by Day 20 KB.
GROUNDED_TESTS = [
    ("A01", "Where is NovaTech Solutions headquartered?", "Noida, India", ["doc-001"]),
    ("A02", "Who led the NovaMind project?", "Priya Mehta", ["doc-005"]),
    ("A03", "When was NovaMind launched?", "February 2026", ["doc-003"]),
    ("A04", "What is NovaTech's internal documentation platform?", "AtlasHub", ["doc-006"]),
    ("A05", "How long does AI Launchpad last?", "six weeks", ["doc-008"]),
    ("A06", "What departments does NovaTech Solutions have?", "Artificial Intelligence, Data Engineering, and Cloud Infrastructure", ["doc-002"]),
    ("A07", "What does NovaMind help employees with?", "company policies, projects, internal documentation, and technical procedures", ["doc-004"]),
    ("A08", "What certification do employees receive after AI Launchpad?", "Nova AI Engineer Level 1", ["doc-009"]),
    ("A09", "When is the weekly technical review meeting?", "Friday at 4 PM", ["doc-010"]),
    ("A10", "What does AtlasHub contain?", "APIs, deployment procedures, incident response processes, and internal coding standards", ["doc-007"]),
]

# 10 natural user-style queries.
USER_STYLE_TESTS = [
    ("U01", "hey can u tell me where novatech is based?"),
    ("U02", "Who was the person behind that NovaMind project again?"),
    ("U03", "so like when did NovaMind actually start?"),
    ("U04", "what's that internal docs thing called at NovaTech?"),
    ("U05", "AI Launchpad is for what exactly and how long is it?"),
    ("U06", "can you just tell me the departments there, like all of them"),
    ("U07", "I'm trying to understand NovaMind — what does it actually do for employees?"),
    ("U08", "after finishing that AI Launchpad training, do people get some certificate?"),
    ("U09", "when do the engineering folks have their weekly tech review?"),
    ("U10", "what kind of stuff can I find inside AtlasHub?"),
]

# 5 completely out-of-domain queries.
OOD_TESTS = [
    ("G01", "What is the weather in Delhi today?"),
    ("G02", "Who won the latest FIFA World Cup?"),
    ("G03", "How do I cook paneer butter masala?"),
    ("G04", "What is the current price of Bitcoin?"),
    ("G05", "How can I renew my Indian passport?"),
    ("G06", "What is the capital of Australia?"),
    ("G07", "Can you explain photosynthesis?"),
    ("G08", "What are the best tourist places in Japan?"),
    ("G09", "How do I calculate compound interest?"),
    ("G10", "Who is the current CEO of Microsoft?"),
]

def call_rag(query):
    retrieved = retrieve_top_k(query, k=3)
    context = format_context(retrieved)
    user_prompt = f"""CONTEXT
=======
{context}

QUESTION
========
{query}
"""
    response = client.chat.completions.create(
        model=MODEL_NAME,
        messages=[
            {"role": "system", "content": RAG_SYSTEM_PROMPT},
            {"role": "user", "content": user_prompt},
        ],
    )
    answer = response.choices[0].message.content or ""
    return answer, retrieved, context

def contains_expected(answer, expected):
    a = answer.lower()
    # Flexible checks for multi-part facts.
    if expected == "Artificial Intelligence, Data Engineering, and Cloud Infrastructure":
        return all(x in a for x in ["artificial intelligence", "data engineering", "cloud infrastructure"])
    if expected == "company policies, projects, internal documentation, and technical procedures":
        return all(x in a for x in ["company policies", "projects", "internal documentation", "technical procedures"])
    if expected == "APIs, deployment procedures, incident response processes, and internal coding standards":
        return all(x in a for x in ["apis", "deployment procedures", "incident response", "coding standards"])
    return expected.lower() in a

def has_honest_uncertainty(answer):
    a = answer.lower()
    phrases = [
        "i don't know",
        "not in the provided context",
        "not provided in the context",
        "cannot be confirmed",
        "can't confirm",
        "insufficient information",
        "information is not available",
        "based on the provided context",
        "not available in the knowledge base",
    ]
    return any(p in a for p in phrases)

def has_user_actionable_citation(answer):
    a = answer.lower()
    # Day 20 currently emits [doc-xxx] only in context, not in final answer.
    # We accept readable forms such as "Source: doc-001" or "[doc-001]".
    for i in range(1, 11):
        doc = f"doc-{i:03d}"
        if doc in a and ("source" in a or "[" in a or "citation" in a or "reference" in a):
            return True
    return False

def score_1_to_5(rate):
    return round(1 + 4 * rate, 2)

def run_tests():
    rows = []

    # Accuracy + reliability + transparency on 10 grounded queries.
    for tid, q, expected, expected_docs in GROUNDED_TESTS:
        t0 = time.perf_counter()
        error = ""
        try:
            answer, retrieved, _ = call_rag(q)
            latency = time.perf_counter() - t0
        except Exception as e:
            answer = ""
            retrieved = []
            latency = time.perf_counter() - t0
            error = f"{type(e).__name__}: {e}"

        ids = [x["id"] for x in retrieved]
        accuracy_pass = bool(answer) and contains_expected(answer, expected)
        reliability_pass = not bool(error) and bool(answer)
        transparency_pass = has_user_actionable_citation(answer)

        rows.append({
            "test_id": tid,
            "dimension": "accuracy",
            "query": q,
            "expected": expected,
            "answer": answer,
            "retrieved_ids": ",".join(ids),
            "latency_s": round(latency, 4),
            "pass": accuracy_pass,
            "error": error,
        })
        rows.append({
            "test_id": tid,
            "dimension": "reliability",
            "query": q,
            "expected": "successful response without exception",
            "answer": answer,
            "retrieved_ids": ",".join(ids),
            "latency_s": round(latency, 4),
            "pass": reliability_pass,
            "error": error,
        })
        rows.append({
            "test_id": tid,
            "dimension": "transparency",
            "query": q,
            "expected": "readable source citation in final answer",
            "answer": answer,
            "retrieved_ids": ",".join(ids),
            "latency_s": round(latency, 4),
            "pass": transparency_pass,
            "error": error,
        })

    # Graceful degradation.
    for tid, q in OOD_TESTS:
        t0 = time.perf_counter()
        error = ""
        try:
            answer, retrieved, _ = call_rag(q)
            latency = time.perf_counter() - t0
        except Exception as e:
            answer = ""
            retrieved = []
            latency = time.perf_counter() - t0
            error = f"{type(e).__name__}: {e}"

        honest = has_honest_uncertainty(answer)
        # For OOD questions, honest uncertainty is the pass condition.
        rows.append({
            "test_id": tid,
            "dimension": "graceful_degradation",
            "query": q,
            "expected": "honest uncertainty / refusal to invent",
            "answer": answer,
            "retrieved_ids": ",".join(x["id"] for x in retrieved),
            "latency_s": round(latency, 4),
            "pass": honest and not error,
            "error": error,
        })

    # Latency: exactly 10 queries, timed end-to-end and by component.
    latency_rows = []
    for tid, q, *_ in GROUNDED_TESTS:
        t0 = time.perf_counter()
        e0 = time.perf_counter()
        retrieved = retrieve_top_k(q, k=3)
        retrieval_s = time.perf_counter() - e0

        e1 = time.perf_counter()
        context = format_context(retrieved)
        context_s = time.perf_counter() - e1

        user_prompt = f"""CONTEXT
=======
{context}

QUESTION
========
{q}
"""
        e2 = time.perf_counter()
        response = client.chat.completions.create(
            model=MODEL_NAME,
            messages=[
                {"role": "system", "content": RAG_SYSTEM_PROMPT},
                {"role": "user", "content": user_prompt},
            ],
        )
        generation_s = time.perf_counter() - e2
        total_s = time.perf_counter() - t0

        latency_rows.append({
            "test_id": tid,
            "query": q,
            "retrieval_s": round(retrieval_s, 4),
            "context_formatting_s": round(context_s, 4),
            "generation_s": round(generation_s, 4),
            "end_to_end_s": round(total_s, 4),
        })

    # User-style queries.
    user_rows = []
    for tid, q in USER_STYLE_TESTS:
        t0 = time.perf_counter()
        try:
            answer, retrieved, _ = call_rag(q)
            error = ""
        except Exception as e:
            answer = ""
            retrieved = []
            error = f"{type(e).__name__}: {e}"
        latency = time.perf_counter() - t0
        user_rows.append({
            "test_id": tid,
            "query": q,
            "answer": answer,
            "retrieved_ids": ",".join(x["id"] for x in retrieved),
            "latency_s": round(latency, 4),
            "error": error,
        })

    write_csv(OUT / "quality_test_results.csv", rows)
    write_csv(OUT / "latency_results.csv", latency_rows)
    write_csv(OUT / "user_style_results.csv", user_rows)

    return rows, latency_rows, user_rows

def write_csv(path, rows):
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

def make_report(rows, latency_rows, user_rows):
    def dim_stats(dim):
        subset = [r for r in rows if r["dimension"] == dim]
        passes = sum(bool(r["pass"]) for r in subset)
        rate = passes / len(subset) if subset else 0
        return len(subset), passes, rate, score_1_to_5(rate)

    dims = {}
    for dim in ["accuracy", "reliability", "transparency", "graceful_degradation"]:
        dims[dim] = dim_stats(dim)

    e2e = [r["end_to_end_s"] for r in latency_rows]
    retrieval = [r["retrieval_s"] for r in latency_rows]
    context = [r["context_formatting_s"] for r in latency_rows]
    generation = [r["generation_s"] for r in latency_rows]

    avg_e2e = statistics.mean(e2e)
    avg_retrieval = statistics.mean(retrieval)
    avg_context = statistics.mean(context)
    avg_generation = statistics.mean(generation)

    components = {
        "retrieval": avg_retrieval,
        "context formatting": avg_context,
        "LLM generation": avg_generation,
    }
    bottleneck = max(components, key=components.get)

    # Latency score: practical rubric for this local challenge.
    if avg_e2e <= 2:
        latency_score = 5
    elif avg_e2e <= 4:
        latency_score = 4
    elif avg_e2e <= 7:
        latency_score = 3
    elif avg_e2e <= 10:
        latency_score = 2
    else:
        latency_score = 1

    report = f"""# Day 21 — AI Product Quality Audit

## 1. Product quality dimensions

| Dimension | One-sentence definition |
|---|---|
| Accuracy | The system gives answers that are correct and supported by the available knowledge base. |
| Latency | The system responds quickly enough for the intended user experience. |
| Reliability | The system consistently completes requests without crashes, API errors, or unstable behavior. |
| Transparency | The system clearly shows where an answer came from so a non-technical user can understand and verify it. |
| Graceful degradation | When the system lacks relevant knowledge or fails, it communicates uncertainty honestly instead of inventing an answer. |

## 2. Day 20 system under test

The Day 20 assistant uses `all-MiniLM-L6-v2` embeddings, FAISS `IndexFlatL2`, top-3 retrieval, context formatting, and an OpenAI generation step. The RAG prompt instructs the model to use only retrieved context and to say “I don't know based on the provided context” when the answer is absent.

## 3. Scores

| Dimension | Tests | Passes | Pass rate | Score / 5 |
|---|---:|---:|---:|---:|
| Accuracy | {dims["accuracy"][0]} | {dims["accuracy"][1]} | {dims["accuracy"][2]*100:.1f}% | {dims["accuracy"][3]:.2f} |
| Latency | 10 | — | — | {latency_score}/5 |
| Reliability | {dims["reliability"][0]} | {dims["reliability"][1]} | {dims["reliability"][2]*100:.1f}% | {dims["reliability"][3]:.2f} |
| Transparency | {dims["transparency"][0]} | {dims["transparency"][1]} | {dims["transparency"][2]*100:.1f}% | {dims["transparency"][3]:.2f} |
| Graceful degradation | {dims["graceful_degradation"][0]} | {dims["graceful_degradation"][1]} | {dims["graceful_degradation"][2]*100:.1f}% | {dims["graceful_degradation"][3]:.2f} |

## 4. Latency measurements

Average end-to-end latency across 10 queries: **{avg_e2e:.3f} seconds**

| Pipeline component | Average latency |
|---|---:|
| Retrieval / embedding + FAISS | {avg_retrieval:.3f}s |
| Context formatting | {avg_context:.3f}s |
| LLM generation | {avg_generation:.3f}s |

**Largest time consumer:** {bottleneck}.

## 5. Graceful degradation — 5 out-of-domain queries

The five OOD queries were intentionally about weather, FIFA, cooking, Bitcoin, and passport renewal. A pass required an explicit uncertainty signal and no exception.

See `results/quality_test_results.csv` for the exact answers and retrieved chunks.

## 6. Transparency audit

A transparency pass requires a readable citation in the **final answer**, not merely an internal retrieved-document ID. The Day 20 pipeline currently places document IDs in the context sent to the model, but does not enforce a source citation in the final response. This is therefore an important product-quality risk.

## 7. Natural-language user-style evaluation

Ten casual, vague, or verbose queries were run in `results/user_style_results.csv`.

Review these outputs for:
- vocabulary mismatch
- overly broad retrieval
- missing facts
- unnecessary uncertainty
- citation quality
- response readability

## 8. What passes

- Grounded factual questions are directly testable against the known 10-document knowledge base.
- Retrieval and generation are separated into measurable pipeline stages.
- The RAG prompt explicitly prohibits guessing.
- The system can be benchmarked repeatedly using CSV outputs.

## 9. What fails / product risks

1. **No enforced retrieval relevance threshold in the Day 20 RAG generation path.** Top-3 retrieval can return semantically related but irrelevant documents for unknown questions.
2. **No guaranteed final-answer citations.** A non-technical user cannot reliably trace an answer back to a document.
3. **Generation/API dependency.** An OpenAI/API failure can prevent a response unless a fallback path is added.
4. **Top-3 retrieval limits broad questions.** The earlier Day 20 diagnostics already showed that broad multi-topic queries can miss required documents.
5. **Natural-language ambiguity can expose retrieval weaknesses.**

## 10. Top three priorities before launching

### Priority 1 — Add abstention / relevance gating
Before generation, reject or soften the answer when the best retrieval score is not sufficiently relevant. This is the highest priority because it directly reduces hallucination risk.

### Priority 2 — Make citations a product requirement
Return citations such as `Source: doc-006 — AtlasHub documentation` in every grounded response. Do not rely on hidden/internal context.

### Priority 3 — Improve production reliability and latency
Add API error handling, retries with limits, graceful fallback messaging, and persistent latency monitoring. Cache embeddings/index data so startup cost does not affect users.

## 11. Launch decision

**Recommendation: NOT READY for a real-user launch yet.**

The Day 20 assistant is a solid engineering prototype, but the audit should be treated as a product-quality gate: unknown questions, citations, and failure handling need stronger guarantees before exposing it to real users.

## 12. Evidence files

- `results/quality_test_results.csv`
- `results/latency_results.csv`
- `results/user_style_results.csv`

These files are generated by `audit.py` from the actual Day 20 assistant.
"""
    (OUT / "DAY21_PRODUCT_QUALITY_REPORT.md").write_text(report, encoding="utf-8")

if __name__ == "__main__":
    print("=" * 70)
    print("DAY 21 — AI PRODUCT QUALITY AUDIT")
    print("=" * 70)
    rows, latency_rows, user_rows = run_tests()
    make_report(rows, latency_rows, user_rows)
    print("\nCompleted.")
    print("Generated:")
    print("  results/quality_test_results.csv")
    print("  results/latency_results.csv")
    print("  results/user_style_results.csv")
    print("  results/DAY21_PRODUCT_QUALITY_REPORT.md")
